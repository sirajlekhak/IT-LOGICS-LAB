export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      repairs: {
        Row: {
          id: string
          customer_name: string
          customer_email: string
          customer_phone: string | null
          device_type: string
          device_brand: string
          device_model: string
          issue_description: string
          status: string
          technician_id: string | null
          estimated_cost: number | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          customer_name: string
          customer_email: string
          customer_phone?: string | null
          device_type: string
          device_brand: string
          device_model: string
          issue_description: string
          status?: string
          technician_id?: string | null
          estimated_cost?: number | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          customer_name?: string
          customer_email?: string
          customer_phone?: string | null
          device_type?: string
          device_brand?: string
          device_model?: string
          issue_description?: string
          status?: string
          technician_id?: string | null
          estimated_cost?: number | null
          created_at?: string
          updated_at?: string
        }
      }
      repair_notes: {
        Row: {
          id: string
          repair_id: string
          technician_id: string
          note: string
          created_at: string
        }
        Insert: {
          id?: string
          repair_id: string
          technician_id: string
          note: string
          created_at?: string
        }
        Update: {
          id?: string
          repair_id?: string
          technician_id?: string
          note?: string
          created_at?: string
        }
      }
      invoices: {
        Row: {
          id: string
          repair_id: string
          amount: number
          status: string
          issued_date: string
          due_date: string
          paid_date: string | null
          created_at: string
        }
        Insert: {
          id?: string
          repair_id: string
          amount: number
          status?: string
          issued_date?: string
          due_date: string
          paid_date?: string | null
          created_at?: string
        }
        Update: {
          id?: string
          repair_id?: string
          amount?: number
          status?: string
          issued_date?: string
          due_date?: string
          paid_date?: string | null
          created_at?: string
        }
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
  }
}