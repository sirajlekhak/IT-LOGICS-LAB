import React, { useState, useEffect, useCallback } from 'react';
import { supabase } from '../lib/supabase';
import { AlertCircle, Archive, CheckSquare, Download, Edit, Eye, FileSpreadsheet, File as FilePdf, Loader2, MoreVertical, Plus, RefreshCw, Search, Trash2, X } from 'lucide-react'ib/utils';
import type { Database } from '../lib/database.types';

type Repair = Database['public']['Tables']['repairs']['Row'];
type NewRepair = Database['public']['Tables']['repairs']['Insert'];
type SortConfig = {
  key: keyof Repair;
  direction: 'asc' | 'desc';
};

type Filter = {
  field: keyof Repair;
  value: string;
};

export function CRMDashboard() {
  const [repairs, setRepairs] = useState<Repair[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedRecords, setSelectedRecords] = useState<string[]>([]);
  const [sortConfig, setSortConfig] = useState<SortConfig>({ key: 'created_at', direction: 'desc' });
  const [filters, setFilters] = useState<Filter[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [showAdvancedFilters, setShowAdvancedFilters] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState<string | null>(null);
  const [showBulkDeleteConfirm, setShowBulkDeleteConfirm] = useState(false);
  const [editingRepair, setEditingRepair] = useState<Repair | null>(null);
  const [showNewRepairForm, setShowNewRepairForm] = useState(false);
  const [newRepair, setNewRepair] = useState<NewRepair>({
    customer_name: '',
    customer_email: '',
    customer_phone: '',
    device_type: '',
    device_brand: '',
    device_model: '',
    issue_description: '',
    estimated_cost: 0,
    status: 'pending'
  });
  const [notification, setNotification] = useState<{ type: 'success' | 'error', message: string } | null>(null);

  const itemsPerPage = 10;

  const fetchRepairs = useCallback(async () => {
    setLoading(true);
    try {
      let query = supabase
        .from('repairs')
        .select('*')
        .order(sortConfig.key, { ascending: sortConfig.direction === 'asc' });

      // Apply filters
      filters.forEach(filter => {
        query = query.ilike(filter.field, `%${filter.value}%`);
      });

      // Apply search
      if (searchQuery) {
        query = query.or(`customer_name.ilike.%${searchQuery}%,device_type.ilike.%${searchQuery}%,issue_description.ilike.%${searchQuery}%`);
      }

      const { data, error } = await query;

      if (error) throw error;
      setRepairs(data || []);
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch repairs');
      setNotification({ type: 'error', message: 'Failed to fetch repairs' });
    } finally {
      setLoading(false);
    }
  }, [sortConfig, filters, searchQuery]);

  useEffect(() => {
    fetchRepairs();
  }, [fetchRepairs]);

  const handleSort = (key: keyof Repair) => {
    setSortConfig(current => ({
      key,
      direction: current.key === key && current.direction === 'asc' ? 'desc' : 'asc'
    }));
  };

  const handleDelete = async (id: string) => {
    try {
      const { error } = await supabase
        .from('repairs')
        .delete()
        .eq('id', id);

      if (error) throw error;
      
      setRepairs(current => current.filter(repair => repair.id !== id));
      setNotification({ type: 'success', message: 'Record deleted successfully' });
    } catch (err) {
      setNotification({ type: 'error', message: 'Failed to delete record' });
    }
    setShowDeleteConfirm(null);
  };

  const handleEdit = async (repair: Repair) => {
    try {
      const { error } = await supabase
        .from('repairs')
        .update(repair)
        .eq('id', repair.id);

      if (error) throw error;
      
      setRepairs(current =>
        current.map(r => r.id === repair.id ? repair : r)
      );
      setEditingRepair(null);
      setNotification({ type: 'success', message: 'Record updated successfully' });
    } catch (err) {
      setNotification({ type: 'error', message: 'Failed to update record' });
    }
  };

  const handleCreateRepair = async () => {
    try {
      const { data, error } = await supabase
        .from('repairs')
        .insert([newRepair])
        .select();

      if (error) throw error;

      setRepairs(current => [...current, ...data]);
      setShowNewRepairForm(false);
      setNewRepair({
        customer_name: '',
        customer_email: '',
        customer_phone: '',
        device_type: '',
        device_brand: '',
        device_model: '',
        issue_description: '',
        estimated_cost: 0,
        status: 'pending'
      });
      setNotification({ type: 'success', message: 'Repair record created successfully' });
    } catch (err) {
      setNotification({ type: 'error', message: 'Failed to create repair record' });
    }
  };

  const handleBulkDelete = async () => {
    try {
      const { error } = await supabase
        .from('repairs')
        .delete()
        .in('id', selectedRecords);

      if (error) throw error;
      
      setRepairs(current => current.filter(repair => !selectedRecords.includes(repair.id)));
      setSelectedRecords([]);
      setNotification({ type: 'success', message: 'Records deleted successfully' });
    } catch (err) {
      setNotification({ type: 'error', message: 'Failed to delete records' });
    }
    setShowBulkDeleteConfirm(false);
  };

  const handleExport = (record: Repair) => {
    const data = JSON.stringify(record, null, 2);
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `repair-${record.id}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleBulkExport = () => {
    const selectedData = repairs.filter(repair => selectedRecords.includes(repair.id));
    const data = JSON.stringify(selectedData, null, 2);
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'repairs-export.json';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleArchive = async (id: string, currentStatus: string) => {
    const newStatus = currentStatus === 'archived' ? 'pending' : 'archived';
    try {
      const { error } = await supabase
        .from('repairs')
        .update({ status: newStatus })
        .eq('id', id);

      if (error) throw error;
      
      setRepairs(current =>
        current.map(repair =>
          repair.id === id ? { ...repair, status: newStatus } : repair
        )
      );
      setNotification({ type: 'success', message: `Record ${newStatus === 'archived' ? 'archived' : 'unarchived'} successfully` });
    } catch (err) {
      setNotification({ type: 'error', message: `Failed to ${newStatus === 'archived' ? 'archive' : 'unarchive'} record` });
    }
  };

  const handleBulkArchive = async () => {
    try {
      const { error } = await supabase
        .from('repairs')
        .update({ status: 'archived' })
        .in('id', selectedRecords);

      if (error) throw error;
      
      setRepairs(current =>
        current.map(repair =>
          selectedRecords.includes(repair.id) ? { ...repair, status: 'archived' } : repair
        )
      );
      setSelectedRecords([]);
      setNotification({ type: 'success', message: 'Records archived successfully' });
    } catch (err) {
      setNotification({ type: 'error', message: 'Failed to archive records' });
    }
  };

  const totalPages = Math.ceil(repairs.length / itemsPerPage);
  const paginatedRepairs = repairs.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  return (
    <div className="p-6 max-w-full overflow-x-auto">
      {/* Header */}
      <div className="mb-6 flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <h1 className="text-2xl font-bold text-gray-900">CRM Dashboard</h1>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowNewRepairForm(true)}
            className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
          >
            <Plus className="h-4 w-4" />
            New Repair
          </button>
          <button
            onClick={fetchRepairs}
            className="inline-flex items-center gap-2 px-4 py-2 bg-gray-100 text-gray-700 rounded-md hover:bg-gray-200"
          >
            <RefreshCw className="h-4 w-4" />
            Refresh
          </button>
          <button
            onClick={() => setShowAdvancedFilters(!showAdvancedFilters)}
            className="inline-flex items-center gap-2 px-4 py-2 bg-gray-100 text-gray-700 rounded-md hover:bg-gray-200"
          >
            <Search className="h-4 w-4" />
            {showAdvancedFilters ? 'Hide Filters' : 'Show Filters'}
          </button>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="mb-6 space-y-4">
        <div className="flex gap-4">
          <div className="flex-1">
            <input
              type="text"
              placeholder="Search repairs..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full px-4 py-2 border rounded-md"
            />
          </div>
          {selectedRecords.length > 0 && (
            <div className="flex items-center gap-2">
              <button
                onClick={() => setShowBulkDeleteConfirm(true)}
                className="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700"
              >
                Delete Selected
              </button>
              <button
                onClick={handleBulkExport}
                className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700"
              >
                Export Selected
              </button>
              <button
                onClick={handleBulkArchive}
                className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
              >
                Archive Selected
              </button>
            </div>
          )}
        </div>

        {showAdvancedFilters && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-4 bg-gray-50 rounded-md">
            <div>
              <label className="block text-sm font-medium text-gray-700">Status</label>
              <select
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                onChange={(e) => setFilters(current => [...current, { field: 'status', value: e.target.value }])}
              >
                <option value="">All</option>
                <option value="pending">Pending</option>
                <option value="in_progress">In Progress</option>
                <option value="completed">Completed</option>
                <option value="archived">Archived</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">Device Type</label>
              <input
                type="text"
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                placeholder="Filter by device type"
                onChange={(e) => setFilters(current => [...current, { field: 'device_type', value: e.target.value }])}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">Date Range</label>
              <input
                type="date"
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                onChange={(e) => setFilters(current => [...current, { field: 'created_at', value: e.target.value }])}
              />
            </div>
          </div>
        )}
      </div>

      {/* Table */}
      <div className="bg-white rounded-lg shadow overflow-hidden">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="w-8 px-6 py-3">
                <input
                  type="checkbox"
                  checked={selectedRecords.length === repairs.length}
                  onChange={(e) => {
                    if (e.target.checked) {
                      setSelectedRecords(repairs.map(r => r.id));
                    } else {
                      setSelectedRecords([]);
                    }
                  }}
                  className="rounded border-gray-300"
                />
              </th>
              {[
                { key: 'id', label: 'ID' },
                { key: 'customer_name', label: 'Customer' },
                { key: 'device_type', label: 'Device' },
                { key: 'status', label: 'Status' },
                { key: 'created_at', label: 'Created' },
                { key: 'estimated_cost', label: 'Cost' },
              ].map(({ key, label }) => (
                <th
                  key={key}
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer hover:bg-gray-100"
                  onClick={() => handleSort(key as keyof Repair)}
                >
                  <div className="flex items-center gap-2">
                    {label}
                    {sortConfig.key === key && (
                      <span>{sortConfig.direction === 'asc' ? '↑' : '↓'}</span>
                    )}
                  </div>
                </th>
              ))}
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                Actions
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {loading ? (
              <tr>
                <td colSpan={8} className="px-6 py-4 text-center">
                  <Loader2 className="h-6 w-6 animate-spin mx-auto" />
                </td>
              </tr>
            ) : paginatedRepairs.length === 0 ? (
              <tr>
                <td colSpan={8} className="px-6 py-4 text-center text-gray-500">
                  No records found
                </td>
              </tr>
            ) : (
              paginatedRepairs.map((repair) => (
                <tr key={repair.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4">
                    <input
                      type="checkbox"
                      checked={selectedRecords.includes(repair.id)}
                      onChange={(e) => {
                        if (e.target.checked) {
                          setSelectedRecords(current => [...current, repair.id]);
                        } else {
                          setSelectedRecords(current =>
                            current.filter(id => id !== repair.id)
                          );
                        }
                      }}
                      className="rounded border-gray-300"
                    />
                  </td>
                  <td className="px-6 py-4 text-sm font-mono">{repair.id}</td>
                  <td className="px-6 py-4">{repair.customer_name}</td>
                  <td className="px-6 py-4">{repair.device_type}</td>
                  <td className="px-6 py-4">
                    <span
                      className={cn(
                        'px-2 inline-flex text-xs leading-5 font-semibold rounded-full',
                        {
                          'bg-yellow-100 text-yellow-800': repair.status === 'pending',
                          'bg-blue-100 text-blue-800': repair.status === 'in_progress',
                          'bg-green-100 text-green-800': repair.status === 'completed',
                          'bg-gray-100 text-gray-800': repair.status === 'archived',
                        }
                      )}
                    >
                      {repair.status}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    {new Date(repair.created_at).toLocaleDateString()}
                  </td>
                  <td className="px-6 py-4">
                    ${repair.estimated_cost?.toFixed(2) || '0.00'}
                  </td>
                  <td className="px-6 py-4 text-right text-sm font-medium space-x-2">
                    <button
                      onClick={() => setEditingRepair(repair)}
                      className="text-indigo-600 hover:text-indigo-900"
                    >
                      <Edit className="h-4 w-4" />
                    </button>
                    <button
                      onClick={() => handleArchive(repair.id, repair.status)}
                      className="text-blue-600 hover:text-blue-900"
                    >
                      <Archive className="h-4 w-4" />
                    </button>
                    <button
                      onClick={() => handleExport(repair)}
                      className="text-green-600 hover:text-green-900"
                    >
                      <Download className="h-4 w-4" />
                    </button>
                    <button
                      onClick={() => setShowDeleteConfirm(repair.id)}
                      className="text-red-600 hover:text-red-900"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      <div className="mt-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="text-sm text-gray-700">
            Showing {(currentPage - 1) * itemsPerPage + 1} to{' '}
            {Math.min(currentPage * itemsPerPage, repairs.length)} of {repairs.length} results
          </span>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
            disabled={currentPage === 1}
            className="px-3 py-1 rounded-md bg-gray-100 text-gray-700 disabled:opacity-50"
          >
            Previous
          </button>
          <span className="text-sm text-gray-700">
            Page {currentPage} of {totalPages}
          </span>
          <button
            onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
            disabled={currentPage === totalPages}
            className="px-3 py-1 rounded-md bg-gray-100 text-gray-700 disabled:opacity-50"
          >
            Next
          </button>
        </div>
      </div>

      {/* New Repair Form Modal */}
      {showNewRepairForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg p-6 max-w-lg w-full">
            <h3 className="text-lg font-medium text-gray-900 mb-4">New Repair</h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">Customer Name</label>
                <input
                  type="text"
                  value={newRepair.customer_name}
                  onChange={(e) => setNewRepair({ ...newRepair, customer_name: e.target.value })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Customer Email</label>
                <input
                  type="email"
                  value={newRepair.customer_email}
                  onChange={(e) => setNewRepair({ ...newRepair, customer_email: e.target.value })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Customer Phone</label>
                <input
                  type="tel"
                  value={newRepair.customer_phone || ''}
                  onChange={(e) => setNewRepair({ ...newRepair, customer_phone: e.target.value })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Device Type</label>
                <input
                  type="text"
                  value={newRepair.device_type}
                  onChange={(e) => setNewRepair({ ...newRepair, device_type: e.target.value })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Device Brand</label>
                <input
                  type="text"
                  value={newRepair.device_brand}
                  onChange={(e) => setNewRepair({ ...newRepair, device_brand: e.target.value })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Device Model</label>
                <input
                  type="text"
                  value={newRepair.device_model}
                  onChange={(e) => setNewRepair({ ...newRepair, device_model: e.target.value })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Issue Description</label>
                <textarea
                  value={newRepair.issue_description}
                  onChange={(e) => setNewRepair({ ...newRepair, issue_description: e.target.value })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  rows={3}
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Estimated Cost</label>
                <input
                  type="number"
                  value={newRepair.estimated_cost || ''}
                  onChange={(e) => setNewRepair({ ...newRepair, estimated_cost: parseFloat(e.target.value) })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Status</label>
                <select
                  value={newRepair.status}
                  onChange={(e) => setNewRepair({ ...newRepair, status: e.target.value })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                >
                  <option value="pending">Pending</option>
                  <option value="in_progress">In Progress</option>
                  <option value="completed">Completed</option>
                </select>
              </div>
            </div>
            <div className="mt-6 flex justify-end gap-4">
              <button
                onClick={() => setShowNewRepairForm(false)}
                className="px-4 py-2 text-gray-700 hover:text-gray-900"
              >
                Cancel
              </button>
              <button
                onClick={handleCreateRepair}
                className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
              >
                Create Repair
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Edit Modal */}
      {editingRepair && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg p-6 max-w-lg w-full">
            <h3 className="text-lg font-medium text-gray-900 mb-4">Edit Repair</h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">Customer Name</label>
                <input
                  type="text"
                  value={editingRepair.customer_name}
                  onChange={(e) => setEditingRepair({ ...editingRepair, customer_name: e.target.value })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Device Type</label>
                <input
                  type="text"
                  value={editingRepair.device_type}
                  onChange={(e) => setEditingRepair({ ...editingRepair, device_type: e.target.value })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Status</label>
                <select
                  value={editingRepair.status}
                  onChange={(e) => setEditingRepair({ ...editingRepair, status: e.target.value })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                >
                  <option value="pending">Pending</option>
                  <option value="in_progress">In Progress</option>
                  <option value="completed">Completed</option>
                  <option value="archived">Archived</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Estimated Cost</label>
                <input
                  type="number"
                  value={editingRepair.estimated_cost || ''}
                  onChange={(e) => setEditingRepair({ ...editingRepair, estimated_cost: parseFloat(e.target.value) })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                />
              </div>
            </div>
            <div className="mt-6 flex justify-end gap-4">
              <button
                onClick={() => setEditingRepair(null)}
                className="px-4 py-2 text-gray-700 hover:text-gray-900"
              >
                Cancel
              </button>
              <button
                onClick={() => handleEdit(editingRepair)}
                className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
              >
                Save Changes
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Notifications */}
      {notification && (
        <div
          className={cn(
            'fixed bottom-4 right-4 p-4 rounded-md shadow-lg',
            {
              'bg-green-100 text-green-800': notification.type === 'success',
              'bg-red-100 text-red-800': notification.type === 'error',
            }
          )}
        >
          <div className="flex items-center gap-2">
            {notification.type === 'error ' ? (
              <AlertCircle className="h-5 w-5" />
            ) : (
              <CheckSquare className="h-5 w-5" />
            )}
            <p>{notification.message}</p>
            <button
              onClick={() => setNotification(null)}
              className="ml-4 text-gray-500 hover:text-gray-700"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {showDeleteConfirm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg p-6 max-w-sm w-full">
            <h3 className="text-lg font-medium text-gray-900 mb-4">Confirm Delete</h3>
            <p className="text-gray-500 mb-4">
              Are you sure you want to delete this record? This action cannot be undone.
            </p>
            <div className="flex justify-end gap-4">
              <button
                onClick={() => setShowDeleteConfirm(null)}
                className="px-4 py-2 text-gray-700 hover:text-gray-900"
              >
                Cancel
              </button>
              <button
                onClick={() => showDeleteConfirm && handleDelete(showDeleteConfirm)}
                className="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Bulk Delete Confirmation Modal */}
      {showBulkDeleteConfirm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg p-6 max-w-sm w-full">
            <h3 className="text-lg font-medium text-gray-900 mb-4">Confirm Bulk Delete</h3>
            <p className="text-gray-500 mb-4">
              Are you sure you want to delete {selectedRecords.length} records? This action cannot be undone.
            </p>
            <div className="flex justify-end gap-4">
              <button
                onClick={() => setShowBulkDeleteConfirm(false)}
                className="px-4 py-2 text-gray-700 hover:text-gray-900"
              >
                Cancel
              </button>
              <button
                onClick={handleBulkDelete}
                className="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700"
              >
                Delete All
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}