import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';

const Repairs = () => {
  const [repairs, setRepairs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [newRepair, setNewRepair] = useState({
    device: '',
    issue: '',
    status: 'Pending',
  });

  // Fetch repairs from Supabase
  useEffect(() => {
    const fetchRepairs = async () => {
      setLoading(true);
      const { data, error } = await supabase.from('repairs').select('*');

      if (error) {
        setError('Error fetching repairs.');
        console.error('Supabase Error:', error);
      } else {
        setRepairs(data);
      }
      setLoading(false);
    };

    fetchRepairs();
  }, []);

  // Function to add a new repair
  const addRepair = async () => {
    if (!newRepair.device || !newRepair.issue) {
      alert('Please enter device and issue details.');
      return;
    }

    const { data, error } = await supabase
      .from('repairs')
      .insert([newRepair])
      .select();

    if (error) {
      console.error('Error inserting repair:', error);
      setError('Failed to add repair.');
    } else {
      setRepairs([...repairs, ...data]); // Update UI with new repair
      setNewRepair({ device: '', issue: '', status: 'Pending' }); // Reset form
    }
  };

  if (loading) return <p className="text-center">Loading repairs...</p>;
  if (error) return <p className="text-center text-red-500">{error}</p>;

  return (
    <div>
      <h1 className="text-3xl font-bold mb-4">Repairs Management</h1>

      {/* New Repair Form */}
      <div className="bg-white p-4 mb-4 shadow-md rounded-lg">
        <h2 className="text-xl font-semibold mb-2">Add New Repair</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <input
            type="text"
            placeholder="Device Name"
            value={newRepair.device}
            onChange={(e) =>
              setNewRepair({ ...newRepair, device: e.target.value })
            }
            className="border p-2 rounded w-full"
          />
          <input
            type="text"
            placeholder="Issue Description"
            value={newRepair.issue}
            onChange={(e) =>
              setNewRepair({ ...newRepair, issue: e.target.value })
            }
            className="border p-2 rounded w-full"
          />
          <button
            onClick={addRepair}
            className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 w-full"
          >
            Add Repair
          </button>
        </div>
      </div>

      {/* Repairs Table */}
      <table className="w-full bg-white shadow-md rounded-lg">
        <thead>
          <tr className="bg-gray-100">
            <th className="py-2 px-4 text-left">ID</th>
            <th className="py-2 px-4 text-left">Device</th>
            <th className="py-2 px-4 text-left">Issue</th>
            <th className="py-2 px-4 text-left">Status</th>
          </tr>
        </thead>
        <tbody>
          {repairs.map((repair) => (
            <tr key={repair.id} className="border-t">
              <td className="py-2 px-4">{repair.id}</td>
              <td className="py-2 px-4">{repair.device}</td>
              <td className="py-2 px-4">{repair.issue}</td>
              <td className="py-2 px-4">{repair.status}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default Repairs;