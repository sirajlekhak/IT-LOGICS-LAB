import { Wrench, Cpu, Battery, Wifi, HardDrive, Airplay as Display } from 'lucide-react';

export default function Services() {
  return (
    <div className="min-h-screen py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Our Services</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            We provide comprehensive laptop repair services with expert technicians and quality parts.
            All repairs come with our 90-day warranty.
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          <ServiceCard
            icon={<Wrench className="h-8 w-8" />}
            title="Hardware Repairs"
            description="Complete hardware repair services including motherboard repair, component replacement, and upgrades."
            price="Starting from $49"
          />
          <ServiceCard
            icon={<Cpu className="h-8 w-8" />}
            title="CPU Services"
            description="CPU replacement, thermal paste application, and cooling system optimization."
            price="Starting from $79"
          />
          <ServiceCard
            icon={<Battery className="h-8 w-8" />}
            title="Battery Replacement"
            description="Original battery replacement service with warranty and proper disposal of old batteries."
            price="Starting from $59"
          />
          <ServiceCard
            icon={<Wifi className="h-8 w-8" />}
            title="Network Solutions"
            description="Wi-Fi card replacement, antenna repair, and network connectivity troubleshooting."
            price="Starting from $39"
          />
          <ServiceCard
            icon={<HardDrive className="h-8 w-8" />}
            title="Data Recovery"
            description="Professional data recovery services for failed or damaged hard drives."
            price="Starting from $99"
          />
          <ServiceCard
            icon={<Display className="h-8 w-8" />}
            title="Screen Replacement"
            description="LCD/LED screen replacement service with genuine display panels."
            price="Starting from $129"
          />
        </div>

        {/* CTA Section */}
        <div className="mt-16 text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Need Our Services?</h2>
          <p className="text-gray-600 mb-8">
            Contact us today for a free diagnostic consultation
          </p>
          <a
            href="/contact"
            className="inline-block bg-blue-600 text-white px-8 py-3 rounded-md text-lg font-semibold hover:bg-blue-700 transition duration-300"
          >
            Get in Touch
          </a>
        </div>
      </div>
    </div>
  );
}

function ServiceCard({
  icon,
  title,
  description,
  price,
}: {
  icon: React.ReactNode;
  title: string;
  description: string;
  price: string;
}) {
  return (
    <div className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition duration-300">
      <div className="text-blue-600 mb-4">{icon}</div>
      <h3 className="text-xl font-semibold text-gray-900 mb-2">{title}</h3>
      <p className="text-gray-600 mb-4">{description}</p>
      <p className="text-blue-600 font-semibold">{price}</p>
    </div>
  );
}