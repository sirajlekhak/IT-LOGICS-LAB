import { Shield, Award, Clock } from 'lucide-react';

export default function About() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <div
        className="relative bg-cover bg-center py-24"
        style={{
          backgroundImage:
            'linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)), url("https://images.unsplash.com/photo-1581092921461-eab62e97a780?ixlib=rb-1.2.1&auto=format&fit=crop&w=2850&q=80")',
        }}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">About IT Logic Labs</h1>
          <p className="text-xl text-gray-200 max-w-3xl mx-auto">
            Your trusted partner in professional laptop repair services since 2015
          </p>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        {/* Our Story */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold text-gray-900 mb-6">Our Story</h2>
          <div className="prose prose-lg text-gray-600 max-w-none">
            <p className="mb-4">
              Founded in 2015, IT Logic Labs has grown from a small repair shop to a leading technology
              service provider in the region. Our commitment to excellence and customer satisfaction has
              earned us the trust of thousands of satisfied customers.
            </p>
            <p>
              We specialize in laptop repairs across all major brands, offering comprehensive solutions
              for both hardware and software issues. Our team of certified technicians brings years of
              experience and expertise to every repair job.
            </p>
          </div>
        </div>

        {/* Core Values */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          <ValueCard
            icon={<Shield className="h-8 w-8" />}
            title="Quality Assurance"
            description="We use only genuine parts and provide warranty on all our repairs"
          />
          <ValueCard
            icon={<Award className="h-8 w-8" />}
            title="Expert Service"
            description="Our technicians are certified and continuously trained in the latest technologies"
          />
          <ValueCard
            icon={<Clock className="h-8 w-8" />}
            title="Quick Turnaround"
            description="Most repairs are completed within 24-48 hours"
          />
        </div>

        {/* Team Section */}
        <div>
          <h2 className="text-3xl font-bold text-gray-900 mb-6">Our Team</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <TeamMember
              image="https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80"
              name="John Smith"
              role="Lead Technician"
            />
            <TeamMember
              image="https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80"
              name="Sarah Johnson"
              role="Hardware Specialist"
            />
            <TeamMember
              image="https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80"
              name="Michael Chen"
              role="Data Recovery Expert"
            />
          </div>
        </div>
      </div>
    </div>
  );
}

function ValueCard({
  icon,
  title,
  description,
}: {
  icon: React.ReactNode;
  title: string;
  description: string;
}) {
  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="text-blue-600 mb-4">{icon}</div>
      <h3 className="text-xl font-semibold text-gray-900 mb-2">{title}</h3>
      <p className="text-gray-600">{description}</p>
    </div>
  );
}

function TeamMember({
  image,
  name,
  role,
}: {
  image: string;
  name: string;
  role: string;
}) {
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden">
      <img src={image} alt={name} className="w-full h-64 object-cover" />
      <div className="p-6">
        <h3 className="text-xl font-semibold text-gray-900">{name}</h3>
        <p className="text-gray-600">{role}</p>
      </div>
    </div>
  );
}