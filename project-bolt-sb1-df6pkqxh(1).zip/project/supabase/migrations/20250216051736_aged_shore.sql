/*
  # Initial Schema Setup for IT Logic Labs CRM

  1. New Tables
    - `repairs`
      - `id` (uuid, primary key)
      - `customer_name` (text)
      - `customer_email` (text)
      - `customer_phone` (text)
      - `device_type` (text)
      - `device_brand` (text)
      - `device_model` (text)
      - `issue_description` (text)
      - `status` (text)
      - `technician_id` (uuid, references auth.users)
      - `estimated_cost` (numeric)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

    - `repair_notes`
      - `id` (uuid, primary key)
      - `repair_id` (uuid, references repairs)
      - `technician_id` (uuid, references auth.users)
      - `note` (text)
      - `created_at` (timestamp)

    - `invoices`
      - `id` (uuid, primary key)
      - `repair_id` (uuid, references repairs)
      - `amount` (numeric)
      - `status` (text)
      - `issued_date` (timestamp)
      - `due_date` (timestamp)
      - `paid_date` (timestamp)
      - `created_at` (timestamp)

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
*/

-- Create repairs table
CREATE TABLE repairs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_name text NOT NULL,
  customer_email text NOT NULL,
  customer_phone text,
  device_type text NOT NULL,
  device_brand text NOT NULL,
  device_model text NOT NULL,
  issue_description text NOT NULL,
  status text NOT NULL DEFAULT 'pending',
  technician_id uuid REFERENCES auth.users,
  estimated_cost numeric,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create repair_notes table
CREATE TABLE repair_notes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  repair_id uuid REFERENCES repairs ON DELETE CASCADE NOT NULL,
  technician_id uuid REFERENCES auth.users NOT NULL,
  note text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create invoices table
CREATE TABLE invoices (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  repair_id uuid REFERENCES repairs ON DELETE CASCADE NOT NULL,
  amount numeric NOT NULL,
  status text NOT NULL DEFAULT 'pending',
  issued_date timestamptz DEFAULT now(),
  due_date timestamptz NOT NULL,
  paid_date timestamptz,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE repairs ENABLE ROW LEVEL SECURITY;
ALTER TABLE repair_notes ENABLE ROW LEVEL SECURITY;
ALTER TABLE invoices ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Allow authenticated users full access to repairs"
  ON repairs
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Allow authenticated users full access to repair notes"
  ON repair_notes
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Allow authenticated users full access to invoices"
  ON invoices
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Create function to update repair timestamps
CREATE OR REPLACE FUNCTION update_repair_timestamp()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for updating repair timestamps
CREATE TRIGGER update_repair_timestamp
  BEFORE UPDATE ON repairs
  FOR EACH ROW
  EXECUTE FUNCTION update_repair_timestamp();